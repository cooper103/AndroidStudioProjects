package edu.cs4730.krauthprogramfour;
import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;
import java.util.List;
@Dao
public interface ExpenseDao {

    /**
     * Select all scores.
     *
     * @return A {@link LiveData<List<Expense>>>} of all the exps in the table.
     */
    @Query("SELECT * FROM " + Expense.TABLE_NAME)
    LiveData<List<Expense>> selectAll();


    @Query("SELECT * FROM " + Expense.TABLE_NAME + " ORDER BY " + Expense.COLUMN_NAME + " ASC")
    LiveData<List<Expense>> selectByName();

    /**
     * Select a score by the ID.
     *
     * @param id The row ID.
     * @return A {@link LiveData<List<Expense>>>} of the selected exp.
     */
    @Query("SELECT * FROM " + Expense.TABLE_NAME + " WHERE " + Expense.COLUMN_ID + " = :id")
    LiveData<List<Expense>> selectById(long id);


    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertAll(List<Expense> expenses);


    @Query("SELECT COUNT(*) FROM " + Expense.TABLE_NAME)
    int count();

    /**
     * Inserts a score into the table.
     *
     * @param expenseData A new exp.
     * @return The row ID of the newly inserted data.
     */
    @Insert
    long insert(Expense expenseData);

    /**
     * Inserts multiple scores into the database
     *
     * @param expenseDatas An array of new exp data.
     * @return The row IDs of the newly inserted exps.
     */
    @Insert
    long[] insertAll(Expense[] expenseDatas);


    /**
     * Delete a score by the ID.
     *
     * @param id The row ID.
     * @return A number of expenses deleted. This should always be {@code 1}.
     */
    @Query("DELETE FROM " + Expense.TABLE_NAME + " WHERE " + Expense.COLUMN_ID + " = :id")
    int deleteById(long id);

    /**
     * Delete all exps.
     */
    @Query("DELETE FROM " + Expense.TABLE_NAME)
    void deleteAllScores();


    /**
     * Update the expense. The exp is identified by the row ID.
     *
     * @param expenseData The expense to update.
     * @return A number of expenses updated. This should always be {@code 1}.
     */
    @Update
    int update(Expense expenseData);


}
