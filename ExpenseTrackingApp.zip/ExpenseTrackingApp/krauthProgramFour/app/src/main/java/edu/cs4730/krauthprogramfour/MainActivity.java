package edu.cs4730.krauthprogramfour;
import android.os.Bundle;
import android.view.View;
import java.util.List;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import edu.cs4730.krauthprogramfour.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {
    DataViewModel mViewModel;
    ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.toolbar);

        mViewModel = new ViewModelProvider(this).get(DataViewModel.class);

        binding.fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mViewModel.createNew();
            }
        });
        mViewModel.getItemLD().observe(this, new Observer<List<Expense>>() {
            @Override
            public void onChanged(@Nullable List<Expense> s) {
            }
        });
    }
}
