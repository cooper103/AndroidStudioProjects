package edu.cs4730.krauthprogramfour;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;
import android.provider.BaseColumns;

@Entity(tableName = Expense.TABLE_NAME)
public class Expense {
    public long num_exps = 0;
    public static final String TABLE_NAME = "expenses";
    public static final String COLUMN_ID= BaseColumns._ID;
    public static final String COLUMN_NAME = "name";
    public static final String COLUMN_CATEGORY = "category";
    public static final String COLUMN_AMOUNT = "amount";
    public static final String COLUMN_DATE = "date";
    public static final String COLUMN_NOTE = "note";
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(index = true, name = COLUMN_ID)
    public long id;

    @ColumnInfo(name = COLUMN_NAME)
    public String name;

    @ColumnInfo(name = COLUMN_CATEGORY)
    public String category;

    @ColumnInfo(name = COLUMN_DATE)
    public String date;

    @ColumnInfo(name = COLUMN_AMOUNT)
    public float amount;

    @ColumnInfo(name = COLUMN_NOTE)
    public String note;
    public Expense(){
        this.id = num_exps;
        num_exps++;
        this.name = "enter name of expense";
        this.category = "enter category";
        this.date = "enter date";
        this.amount = 0.0F;
        this.note = "add an optional note";
    }
    public Expense(long id, String name, String category, String date, float amount, String note){
        this.id = id;
        this.name = name;
        this.category = category;
        this.date = date;
        this.amount = amount;
        this.note = note;
    }
    public long getId(){
        return id;
    }
    public void setId(long Id){
        this.id = Id;
    }
    public String getName(){
        return name;
    }
    public void setName(String name){
        this.name = name;
    }
    public String getCategory(){
        return category;
    }
    public void setCategory(String category){
        this.category = category;
    }
    public String getDate(){
        return date;
    }
    public void setDate(String date){
        this.date = date;
    }
    public float getAmount(){
        return amount;
    }
    public void setAmount(float amount){
        this.amount = amount;
    }
    public String getNote(){
        return note;
    }
    public void setNote(String note){
        this.note = note;
    }
}
