package edu.cs4730.krauthprogramfour;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import java.util.List;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
public class MainFragment extends Fragment {

    DataViewModel mViewModel;
    RecyclerView mRecyclerView;
    myAdapter mAdapter;
    String TAG = "MainFragment";
    //FragmentMainBinding binding;
    private List<Expense> mList;

    public MainFragment() {
        //mViewModel.createNew();
        //mList = mViewModel.getItem();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View myView = inflater.inflate(R.layout.fragment_main, container, false);
        mViewModel = new ViewModelProvider(requireActivity()).get(DataViewModel.class);
        mList = mViewModel.getItem();
        mRecyclerView = myView.findViewById(R.id.listtrans);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());
        mAdapter = new myAdapter(mViewModel, this,R.layout.row_layout);
        mRecyclerView.setAdapter(mAdapter);
        mViewModel.getItemLD().observe(getViewLifecycleOwner(), new Observer<List<Expense>>() {
            @Override
            public void onChanged(@Nullable List<Expense> s) {
                mAdapter.notifyDataSetChanged();
                if(mViewModel.getItem() != null){
                    Log.d("data changed", mViewModel.getItem().toString());
                } else{
                    Log.d("data changed", "null");
                }
            }
        });
        return myView;
    }
}
