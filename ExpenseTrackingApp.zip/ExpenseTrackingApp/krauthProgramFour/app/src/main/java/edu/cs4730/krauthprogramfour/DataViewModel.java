package edu.cs4730.krauthprogramfour;

import android.util.Log;
import android.app.Application;
import java.util.List;
import androidx.annotation.Nullable;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MediatorLiveData;
import androidx.lifecycle.AndroidViewModel;

public class DataViewModel extends AndroidViewModel {
    private MediatorLiveData<List<Expense>> item;
    private final AppDatabase ad;
    final private String TAG = "ViewModel";
    public DataViewModel(Application application){
        super(application);
        ad = AppDatabase.getInstance(application);
        item = new MediatorLiveData<>();
        item.setValue(null);
        LiveData<List<Expense>> expenses = ad.ExpenseDao().selectAll();
        Log.d("constructor ran", "constructor ran");
        item.addSource(expenses, new androidx.lifecycle.Observer<List<Expense>>(){
            @Override
            public void onChanged(@Nullable List<Expense> expenseEntities){
                item.setValue(expenseEntities);
            }
        });
    }
    public LiveData<List<Expense>> getExpenses(){return item;}

    public LiveData<List<Expense>> getItemLD() {
        //item.setValue("default");
        return item;
    }
    List<Expense> getItem() {
        return item.getValue();
    }
    void setItem(Expense expense, long id) {
        Log.d("VM", "data id is " + id);
        //item.setValue(expenses);
        Thread myThread = new Thread() {
            public void run(){
                ad.ExpenseDao().deleteById(id);
                ad.ExpenseDao().insert(expense);
            }
        };
        myThread.start();
    }
    void createNew(){
        Expense expense = new Expense();
        Thread myThread = new Thread() {
            public void run(){
                ad.ExpenseDao().insert(expense);
            }
        };
        myThread.start();
    }
    void delete_item(long id){
        Thread myThread = new Thread() {
            public void run(){
                Log.d("the delete ran", "delete ran" + id);
                ad.ExpenseDao().deleteById(id);
            }
        };
        myThread.start();

    }
}
