package edu.cs4730.krauthprogramfour;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import java.util.List;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.recyclerview.widget.RecyclerView;
import edu.cs4730.krauthprogramfour.databinding.RowLayoutBinding;
public class myAdapter extends RecyclerView.Adapter<myAdapter.ViewHolder> {

    private List<Expense> myList;
    private int rowLayout;
    private Fragment mFragment;
    private final String TAG = "myAdapter";
    private DataViewModel mViewModel;

    public static class ViewHolder extends RecyclerView.ViewHolder {
        RowLayoutBinding viewBinding;

        public ViewHolder(RowLayoutBinding itemview) {
            super(itemview.getRoot());
            viewBinding = itemview;
        }
    }
    public myAdapter(DataViewModel dataViewModel, Fragment mFragment, int rowLayout){
        this.rowLayout = rowLayout;
        mViewModel = dataViewModel;
        mViewModel.getExpenses().observe(mFragment, new Observer<List<Expense>>() {
            @Override
            public void onChanged(List<Expense> expenses) {
                myList = expenses;
                notifyDataSetChanged();
            }
        });
    }
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        RowLayoutBinding v = RowLayoutBinding.inflate(LayoutInflater.from(viewGroup.getContext()), viewGroup, false);
        return new ViewHolder(v);

    }

    @Override
    public void onBindViewHolder(ViewHolder viewHolder, int i) {
        List<Expense> list_of_exp = mViewModel.getItem();
        Log.d("made it here", "made it heereeee");
        String name = list_of_exp.get(i).getName();
        String category = list_of_exp.get(i).getCategory();
        String date = list_of_exp.get(i).getDate();
        float amount = list_of_exp.get(i).getAmount();
        String note = list_of_exp.get(i).getNote();

        viewHolder.viewBinding.name.setText(name);
        viewHolder.viewBinding.name.setTag(i);
        viewHolder.viewBinding.category.setText(category);
        viewHolder.viewBinding.category.setTag(i);
        viewHolder.viewBinding.date.setText(date);
        viewHolder.viewBinding.date.setTag(i);
        viewHolder.viewBinding.amount.setText(Float.toString(amount));
        viewHolder.viewBinding.amount.setTag(i);
        viewHolder.viewBinding.note.setText(note);
        viewHolder.viewBinding.note.setTag(i);
        Log.d("ran through this code", list_of_exp.toString());

        viewHolder.viewBinding.delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                long id = list_of_exp.get(i).getId();
                mViewModel.delete_item(id);
                Log.d("ran the funciton call", "function call ran");

            }
        });
        viewHolder.viewBinding.save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Expense exp = new Expense();
                long id = list_of_exp.get(i).getId();
                try {
                    String name_t = String.valueOf(viewHolder.viewBinding.name.getText());
                    exp.setName(name_t);
                    exp.setAmount(Float.parseFloat(viewHolder.viewBinding.amount.getText().toString()));
                    String date = String.valueOf(viewHolder.viewBinding.date.getText());
                    exp.setDate(date);
                    exp.setNote(String.valueOf(viewHolder.viewBinding.note.getText()));
                    String cat = String.valueOf(viewHolder.viewBinding.category.getText());
                    exp.setCategory(cat);
                    if(name_t.isEmpty() || cat.isEmpty() || date.isEmpty()){
                        Log.d("empty entry", "only the optional note can be empty");
                    } else{
                        mViewModel.setItem(exp, id);
                    }
                } catch(NumberFormatException e){
                    Log.d("invalid input", "non-numbered entered into amount");
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return myList == null ? 0 : myList.size();
    }

}
